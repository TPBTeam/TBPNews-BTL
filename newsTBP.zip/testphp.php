<?php
echo strtotime(date());
?>